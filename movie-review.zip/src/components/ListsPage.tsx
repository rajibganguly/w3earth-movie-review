import { useState, useEffect } from 'react';
import './../App.css';
import List from './List';
import { Movie } from './../interface/movie'



const ListsPage = ({ movies }: { movies: Movie[] }) => {


    return (
        <div className="container">
            <h1 className="title">All Movies</h1>
            <List movies={movies} />
        </div>
    );
};

export default ListsPage;