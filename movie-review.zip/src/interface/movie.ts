export interface Movie {
    id: number;
    name: string;
    storyline: string;
    punchfactor: string;
    year: string;
    rate: number;
    imageName: string;
    genre: string;
    artists: string[];
    directors: string[];
}

